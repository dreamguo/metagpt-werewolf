import './App.css';
import WerewolfDemo from './WerewolfDemo';

function App() {
  return (
    <div className="App">
      <WerewolfDemo />
    </div>
  );
}

export default App;